enum Color {
  ROJO,
  NEGRO
}
